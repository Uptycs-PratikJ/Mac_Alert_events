#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1082_MACOS_SQLITE_MESSAGES
sqlite3 Messages/chat.db
