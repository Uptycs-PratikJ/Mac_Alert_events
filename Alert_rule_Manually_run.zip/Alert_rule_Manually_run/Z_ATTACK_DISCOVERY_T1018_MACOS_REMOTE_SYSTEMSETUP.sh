#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1018_MACOS_REMOTE_SYSTEMSETUP
sudo systemsetup -setremoteogin on
sudo systemsetup -setremotelogin off
