#!/usr/bin/env sh
# ATTACK_PRIVILEGE_ESCALATION_T1548_MACOS_DSENABLE
dsenableroot -u myorg -p MDPL @ 123 -r MDPL @ 123
