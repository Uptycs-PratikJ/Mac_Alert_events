#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1546_MACOS_EMOND
sudo emond 
