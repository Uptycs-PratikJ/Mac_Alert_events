#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1547_MACOS_KEXTLOAD
sudo kextload -b com.apple.driver.ExampleBundle