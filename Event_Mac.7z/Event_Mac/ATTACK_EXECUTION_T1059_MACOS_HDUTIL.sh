#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_HDUTIL
hdiutil info -plist /Applications/Safari.app/Contents/MacOS/Safari
