#!/usr/bin/env sh
# ATTACK_EXECUTION_T1053_MACOS_CRON_FILE
sudo sh -c 'printf "\n" >> /etc/crontab'
