#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1057_MACOS_CHGRP
sudo chgrp -R apache dir
