#!/usr/bin/env sh
# ATTACK_COLLECTION_T1115_MACOS_PBPASTE
pbcopy 
pbpaste