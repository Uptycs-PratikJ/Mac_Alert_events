#!/usr/bin/env sh
# ATTACK_CREDENTIAL_ACCESS_T1555_MACOS_KEYCHAINS
security find-certificate
