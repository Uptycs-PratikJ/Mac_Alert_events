#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1083_MACOS_NVRAM
# print out all current NVRAM contents
nvram -xp
# display the output in XML format
nvram -p
