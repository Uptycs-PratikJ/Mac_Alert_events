#!/usr/bin/env sh
#ATTACK_DEFENSE_EVASION_T1027_MACOS_XXD_DECODE
touch file.txt
xxd -p file.txt