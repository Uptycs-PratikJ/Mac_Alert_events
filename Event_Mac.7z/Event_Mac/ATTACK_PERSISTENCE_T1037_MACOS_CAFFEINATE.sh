#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1037_MACOS_CAFFEINATE
caffeinate -t 