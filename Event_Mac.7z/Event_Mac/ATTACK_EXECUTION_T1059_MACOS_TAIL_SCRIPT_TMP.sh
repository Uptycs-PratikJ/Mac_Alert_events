#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_TAIL_SCRIPT_TMP
tail -c 24 /Applications/Safari.app/Contents/MacOS/Safari
