#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1130_MACOS_CA_CERT
security add-trusted-cert
