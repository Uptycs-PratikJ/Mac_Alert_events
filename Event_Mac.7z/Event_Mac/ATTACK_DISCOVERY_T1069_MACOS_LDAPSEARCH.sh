#!/usr/bin/env sh
#ATTACK_DISCOVERY_T1069_MACOS_LDAPSEARCH
networksetup -getinfo
