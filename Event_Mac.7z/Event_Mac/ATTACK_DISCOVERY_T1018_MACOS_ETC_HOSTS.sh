#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1018_MACOS_ETC_HOSTS
cat /etc/hosts
