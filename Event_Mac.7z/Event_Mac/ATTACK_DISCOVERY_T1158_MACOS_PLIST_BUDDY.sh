#!/usr/bin/env sh
#ATTACK_DISCOVERY_T1158_MACOS_PLIST_BUDDY
/usr/libexec/PlistBuddy -c "print :CFBundleShortVersionString" /Applications/Safari.app/Contents/Info.plist
/usr/libexec/PlistBuddy -c "print :CFBundleVersion" /Applications/Safari.app/Contents/Info.plist