#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1069_MACOS_DSCACHEUTIL_GROUP
dscacheutil -q group -a name admin
