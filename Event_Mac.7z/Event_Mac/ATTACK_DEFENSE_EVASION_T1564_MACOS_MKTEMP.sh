#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1564_MACOS_MKTEMP
mktemp -d
mktemp -t
