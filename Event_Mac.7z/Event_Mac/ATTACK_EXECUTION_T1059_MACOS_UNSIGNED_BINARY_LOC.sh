#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_UNSIGNED_BINARY_LOC
/System/Library/CoreServices/slodDiskLabeler

