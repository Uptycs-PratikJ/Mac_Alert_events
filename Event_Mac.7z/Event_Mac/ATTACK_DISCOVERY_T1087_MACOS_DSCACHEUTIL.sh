#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1087_MACOS_DSCACHEUTIL
dscacheutil -q group -a name uptycs
