#!/usr/bin/env sh
# ATTACK_CREDENTIAL_ACCESS_T1552_MACOS_KEYCHAINS
sudo mkdir ~/Downloads/Keychains
sudo touch ~/Downloads/Keychains/ATTACK_CREDENTIAL_ACCESS_T1552_MACOS_KEYCHAINS.txt
sudo rm -rf ~/Downloads/Keychains/
