#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1564_MACOS_HIDDEN_DIR
mkdir /var/tmp/.hidden-directory
echo "T1564.001" > /var/tmp/.hidden-directory/.hidden-file
rmdir -rf /var/tmp/.hidden-directory/
