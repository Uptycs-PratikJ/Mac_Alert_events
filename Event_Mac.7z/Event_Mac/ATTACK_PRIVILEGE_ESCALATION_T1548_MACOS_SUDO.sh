#!/usr/bin/env sh
# ATTACK_PRIVILEGE_ESCALATION_T1548_MACOS_SUDO
sudo touch T1548.txt
sudo rm T1548.txt
