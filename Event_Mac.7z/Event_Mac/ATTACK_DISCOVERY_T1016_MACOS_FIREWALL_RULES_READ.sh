#!/usr/bin/env sh
#ATTACK_DISCOVERY_T1016_MACOS_FIREWALL_RULES_READ
defaults read /Library/Preferences/com.apple.alf.plist