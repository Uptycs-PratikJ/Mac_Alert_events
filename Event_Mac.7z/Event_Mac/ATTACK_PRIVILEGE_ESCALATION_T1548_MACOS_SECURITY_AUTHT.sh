#!/usr/bin/env sh
#ATTACK_PRIVILEGE_ESCALATION_T1548_MACOS_SECURITY_AUTHT
/usr/libexec/security_authtrampoline