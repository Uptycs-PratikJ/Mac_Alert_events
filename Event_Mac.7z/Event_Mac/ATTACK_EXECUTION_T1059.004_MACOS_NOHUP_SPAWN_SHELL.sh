#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059.004_MACOS_NOHUP_SPAWN_SHELL
nohup /bin/sh -c sh </dev/ttys000 >/dev/ttys000 2>/dev/ttys000"
