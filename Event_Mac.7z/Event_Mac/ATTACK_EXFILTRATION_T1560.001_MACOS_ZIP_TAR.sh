#!/usr/bin/env sh
# ATTACK_EXFILTRATION_T1560.001_MACOS_ZIP_TAR
zip -ry blah.zip *
