#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1217_MACOS_BOOKMARKS
touch bookmarks.html
