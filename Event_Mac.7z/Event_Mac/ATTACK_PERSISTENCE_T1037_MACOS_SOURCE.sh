#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1037_MACOS_SOURCE
source /etc/passwd