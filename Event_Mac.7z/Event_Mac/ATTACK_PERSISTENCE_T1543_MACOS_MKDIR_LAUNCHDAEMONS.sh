#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_MKDIR_LAUNCHDAEMONS
sudo mkdir /Library/LaunchDaemons/T1543
sudo rm /Library/LaunchDaemons/T1543
