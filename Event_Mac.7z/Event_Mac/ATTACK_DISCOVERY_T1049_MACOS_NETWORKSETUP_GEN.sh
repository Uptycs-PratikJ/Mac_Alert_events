#!/usr/bin/env sh
#ATTACK_DISCOVERY_T1049_MACOS_NETWORKSETUP_GEN
networksetup -getinfo
