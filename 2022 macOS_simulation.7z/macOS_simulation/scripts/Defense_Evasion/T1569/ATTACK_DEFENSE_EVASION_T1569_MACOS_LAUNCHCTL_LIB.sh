#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1569_MACOS_LAUNCHCTL_LIB
launchctl load library