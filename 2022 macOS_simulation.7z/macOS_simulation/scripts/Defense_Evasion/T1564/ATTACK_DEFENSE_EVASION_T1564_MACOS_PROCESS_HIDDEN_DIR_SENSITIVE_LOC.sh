#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1564_MACOS_PROCESS_HIDDEN_DIR_SENSITIVE_LOC
cp /bin/ls ~/Downloads 
mv ~/Downloads/ls ~/Downloads/.lscopy
cp ~/Downloads/.lscopy /Library/
/Library/.lscopy
rm -rf /Library/.lscopy

