#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1099_MACOS_TOUCH_T_MT
sudo touch -t ~/.bashrc
