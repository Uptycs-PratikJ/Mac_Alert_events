#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1027_MACOS_OPENSSL_ENC_PASS
openssl aes-256-cbc -in some_file.enc -out some_file.unenc -d -pass pass:somepassword
