#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1222_MACOS_CHMOD_HIDDEN
sudo touch /.file
chmod 755 /.file
rm -rf /.file
