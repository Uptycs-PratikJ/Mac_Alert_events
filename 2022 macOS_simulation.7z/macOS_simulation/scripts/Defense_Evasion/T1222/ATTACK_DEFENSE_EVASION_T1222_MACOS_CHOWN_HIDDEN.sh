#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1222_MACOS_CHOWN_HIDDEN
mount -uw /
sudo touch /.file
chown root /.file
sudo rm -rf /.file
