#!/usr/bin/env sh
# ATTACK_IMPACT_T1529_MACOS_SHUTDOWN
sudo shutdown -s +1
