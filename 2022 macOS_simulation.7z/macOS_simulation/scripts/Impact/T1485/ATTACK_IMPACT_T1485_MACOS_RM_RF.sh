#!/usr/bin/env sh
# ATTACK_IMPACT_T1485_MACOS_RM_RF
mkdir test
rm -rf test/
