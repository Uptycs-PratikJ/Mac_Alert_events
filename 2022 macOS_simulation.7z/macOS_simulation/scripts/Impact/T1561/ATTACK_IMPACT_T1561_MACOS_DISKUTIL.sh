#!/usr/bin/env sh
# ATTACK_IMPACT_T1561_MACOS_DISKUTIL
diskutil randomDisk
