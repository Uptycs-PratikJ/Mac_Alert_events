#!/usr/bin/env sh
# ATTACK_CREDENTIAL_DUMP_T1555_MACOS_KEYCHAIN_MODIFY
security dump-keychain -d > keychain.txt
