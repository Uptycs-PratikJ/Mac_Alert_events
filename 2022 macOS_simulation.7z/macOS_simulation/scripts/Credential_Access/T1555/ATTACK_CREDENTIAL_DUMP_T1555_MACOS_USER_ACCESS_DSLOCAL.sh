#!/usr/bin/env sh
# ATTACK_CREDENTIAL_DUMP_T1555_MACOS_USER_ACCESS_DSLOCAL
touch /var/db/dslocal/nodes/Default/users/T1555.plist
rm -rf /var/db/dslocal/nodes/Default/users/T1555.plist
