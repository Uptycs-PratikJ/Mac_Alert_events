#!/usr/bin/env sh
# ATTACK_CREDENTIAL_ACCESS_T1552_MACOS_CREDENTIALS
sudo touch ~/.bashrc
grep 'password' ~/.bashrc
