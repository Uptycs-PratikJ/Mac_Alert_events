#!/usr/bin/env sh
# ATTACK_CREDENTIAL_ACCESS_T1552_MACOS_SSH_HIDDEN
sudo mkdir ~/.ssh
sudo touch ~/.ssh/known_hosts
cat ~/.ssh/known_hosts
