#!/usr/bin/env sh
# ATTACK_CREDENTIAL_ACCESS_T1003_MACOS_ZIP_KEYCHAIN
sudo touch /Library/Keychains/T1003.keychain
sudo zip /Library/Keychains/T1003.keychain file.zip
sudo rm -rf /Library/Keychain/T1003.keychain
sudo rm -rf /Library/Keychain/file.zip