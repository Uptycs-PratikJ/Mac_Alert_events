#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1098_004_MACOS_SSH_AUTHORISED_KEYS
mkdir ~/.ssh
echo "_" >> ~/.ssh/authorized_keys
