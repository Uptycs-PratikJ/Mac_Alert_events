#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_MV_LAUNCHAGENTS
sudo touch /Library/LaunchAgents/T1543.plist
sudo mv /Library/LaunchAgents/T1543.plist ~/Downloads
sudo rm -rf ~/Downloads/T1543.plist
