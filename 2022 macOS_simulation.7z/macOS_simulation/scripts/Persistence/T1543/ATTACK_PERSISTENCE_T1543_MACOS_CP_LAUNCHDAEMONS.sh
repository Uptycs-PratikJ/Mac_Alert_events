#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_CP_LAUNCHDAEMONS
sudo touch /Library/LaunchDaemons/T1543.plist
sudo cp /Library/LaunchDaemons/T1543.plist ~/Downloads/
sudo rm ~/Downloads/T1543.plist
