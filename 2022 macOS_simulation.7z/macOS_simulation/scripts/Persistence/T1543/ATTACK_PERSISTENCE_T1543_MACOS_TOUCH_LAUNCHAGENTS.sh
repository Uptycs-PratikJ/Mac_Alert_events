#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_TOUCH_LAUNCHAGENTS
sudo touch /Library/LaunchAgents/T1543.plist
sudo rm -rf /Library/LaunchAgents/T1543.plist
