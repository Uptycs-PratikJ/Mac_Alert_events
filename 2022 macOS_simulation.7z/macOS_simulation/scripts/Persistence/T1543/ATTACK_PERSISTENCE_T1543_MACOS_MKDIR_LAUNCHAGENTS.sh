#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_MKDIR_LAUNCHAGENTS
sudo mkdir Library/LaunchAgents/T1543
sudo rmdir Library/LaunchAgents/T1543
