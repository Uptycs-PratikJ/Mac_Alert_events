#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_CP_LAUNCHAGENTS
sudo touch /Library/LaunchAgents/T1543.plist
sudo cp /Library/LaunchAgents/T1543.plist ~/Downloads
sleep 3
sudo rm -rf /Library/LaunchAgents/T1543.plist
sudo rm -rf ~/Downloads/T1543.plist
