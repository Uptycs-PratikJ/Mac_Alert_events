#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_PLUTIL
sudo touch Library/Preferences/com.apple.test.plist
plutil -replace Library/Preferences/com.apple.test.plist LSUIElement
sudo rm -rf Library/Preferences/com.apple.test.plist
