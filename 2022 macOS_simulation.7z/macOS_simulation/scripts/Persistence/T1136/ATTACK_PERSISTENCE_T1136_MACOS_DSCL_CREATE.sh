#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1136_MACOS_DSCL_CREATE
dscl -create
