#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1037.004_MACOS_RC_COMMON
echo "V" >> /etc/rc.common
