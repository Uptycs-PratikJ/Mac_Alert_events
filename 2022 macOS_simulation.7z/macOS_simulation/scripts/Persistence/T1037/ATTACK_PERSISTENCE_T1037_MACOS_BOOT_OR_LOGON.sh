#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1037_MACOS_BOOT_OR_LOGON
touch /Library/StartupItems/validating_t1037.plist
