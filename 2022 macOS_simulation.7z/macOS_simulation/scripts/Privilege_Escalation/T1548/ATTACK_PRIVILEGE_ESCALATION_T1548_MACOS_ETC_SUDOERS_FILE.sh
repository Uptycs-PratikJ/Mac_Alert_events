#!/usr/bin/env sh
# ATTACK_PRIVILEGE_ESCALATION_T1548_MACOS_ETC_SUDOERS_FILE
echo " " >> /etc/sudoers
