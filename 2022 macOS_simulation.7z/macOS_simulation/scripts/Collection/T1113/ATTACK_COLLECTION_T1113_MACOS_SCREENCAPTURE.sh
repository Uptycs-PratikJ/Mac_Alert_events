#!/usr/bin/env sh
# ATTACK_COLLECTION_T1113_MACOS_SCREENCAPTURE
screencapture photo.png