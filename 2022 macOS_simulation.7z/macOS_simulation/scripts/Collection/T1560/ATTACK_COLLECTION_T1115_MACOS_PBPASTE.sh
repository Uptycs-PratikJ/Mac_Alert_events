#!/usr/bin/env sh
# ATTACK_COLLECTION_T1115_MACOS_PBPASTE
echo "hi helo" >> ~/Downloaads/file.txt 
cat ~/Downloaads/file.txt | pbcopy 
pbpaste