curl $(cat scripts/Malicious\ IPs/IP.txt)
