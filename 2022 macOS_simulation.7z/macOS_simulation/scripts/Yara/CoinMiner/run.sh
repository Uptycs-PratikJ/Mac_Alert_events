#!/usr/bin/env sh
python3 scripts/Yara/CoinMiner/xmrig_final.py
