#!/usr/bin/env sh
#ATTACK_EXECUTION_T1059_MACOS_CHROME_REMOTE_DEBUGGING
/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome --remote-debugging-port=9222