#!/usr/bin/env sh
#ATTACK_LATERAL_MOVEMENT_T1021_MACOS_SMBUTIL
sudo scutil --set HostName flame01.domain.com