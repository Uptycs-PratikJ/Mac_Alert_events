#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1201_MACOS_PWPOLICY_ACCOUNT
pwpolicy getaccountpolicies
