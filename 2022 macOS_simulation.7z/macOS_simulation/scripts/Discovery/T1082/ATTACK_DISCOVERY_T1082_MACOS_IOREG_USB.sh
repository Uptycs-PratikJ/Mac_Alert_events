#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1082_MACOS_IOREG_USB
/bin/sh ioreg USB Vendor Name