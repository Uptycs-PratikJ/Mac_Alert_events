#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1082_MACOS_SWVERS
sw_vers -productVersion
sw_vers -productName
sw_vers -buildVersion
