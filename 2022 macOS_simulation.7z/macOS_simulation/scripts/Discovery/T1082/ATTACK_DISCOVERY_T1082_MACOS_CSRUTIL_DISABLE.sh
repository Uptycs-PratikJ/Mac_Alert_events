#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1082_MACOS_CSRUTIL_DISABLE
csrutil disable
