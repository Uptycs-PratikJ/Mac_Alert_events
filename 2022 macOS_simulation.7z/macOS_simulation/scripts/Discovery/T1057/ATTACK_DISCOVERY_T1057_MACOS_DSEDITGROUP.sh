#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1057_MACOS_DSEDITGROUP
dseditgroup -u uptycs -P uptycs -o create uptycstesting
