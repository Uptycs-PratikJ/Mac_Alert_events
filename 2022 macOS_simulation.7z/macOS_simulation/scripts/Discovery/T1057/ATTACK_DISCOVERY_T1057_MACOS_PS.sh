#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1057_MACOS_PS
ps -ax >> T1057.txt
