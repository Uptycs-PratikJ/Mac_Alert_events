#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1033_MACOS_ID_UTILITY
/usr/bin/id -F 501
