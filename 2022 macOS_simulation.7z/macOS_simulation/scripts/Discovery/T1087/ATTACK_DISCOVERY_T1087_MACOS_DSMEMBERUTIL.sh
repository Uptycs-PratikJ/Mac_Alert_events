#!/usr/bin/env sh
#ATTACK_DISCOVERY_T1087_MACOS_DSMEMBERUTIL
dsmemberutil checkmembership -U "$deadpool" -G "$home"
