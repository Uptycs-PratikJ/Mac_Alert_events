#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1087_MACOS_DSCL_LIST
dscl . -list /Groups
