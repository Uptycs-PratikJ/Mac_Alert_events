#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1083_MACOS_OPEN_TMP_APP
cp /bin/ls /tmp/ls.app
/usr/bin/open /tmp/ls.app
