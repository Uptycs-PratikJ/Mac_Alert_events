#!/usr/bin/env sh
# ATTACK_EXECUTION_T1546_MACOS_TRAP
trap ls 2
