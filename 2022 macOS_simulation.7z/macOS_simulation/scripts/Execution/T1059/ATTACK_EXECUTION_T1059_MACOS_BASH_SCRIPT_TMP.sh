#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_BASH_SCRIPT_TMP
sudo touch /tmp/T1059.sh
/bin/sh /tmp/T1059.sh
sudo rm /tmp/T1059.sh
