#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_EXECUTION
sudo touch ~/Downloads/T1059.scpt
osascript -l python3 ~/Downloads/T1059.scpt
sudo rm ~/Downloads/T1059.scpt
