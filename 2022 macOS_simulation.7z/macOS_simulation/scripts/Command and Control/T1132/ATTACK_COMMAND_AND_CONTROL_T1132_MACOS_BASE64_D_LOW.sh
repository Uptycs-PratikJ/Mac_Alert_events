#!/usr/bin/env sh
#ATTACK_COMMAND_AND_CONTROL_T1132_MACOS_BASE64_D_LOW
echo "something" >> /tmp/T1132.txt
base64 -D /tmp/T1132.txt
rm -rf /tmp/T1132.txt
