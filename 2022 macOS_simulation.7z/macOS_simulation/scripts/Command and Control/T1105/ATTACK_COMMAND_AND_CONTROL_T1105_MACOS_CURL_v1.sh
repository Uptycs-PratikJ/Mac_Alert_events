#!/usr/bin/env sh
#ATTACK_COMMAND_AND_CONTROL_T1105_MACOS_CURL_v1
curl https://www.kaspersky.co.in/