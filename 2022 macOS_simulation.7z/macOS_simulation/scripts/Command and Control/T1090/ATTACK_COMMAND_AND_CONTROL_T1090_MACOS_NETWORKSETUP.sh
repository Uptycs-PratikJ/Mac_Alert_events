#!/usr/bin/env sh
# ATTACK_COMMAND_AND_CONTROL_T1090_MACOS_NETWORKSETUP
networksetup -setwebproxy