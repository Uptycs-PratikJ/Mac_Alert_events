
#ATTACK_DEFENSE_EVASION_T1027_MACOS_OSACOMPILE\

system ( "osacompile -x ~/Downloads/Toggle Dark Mode.applescript" )
