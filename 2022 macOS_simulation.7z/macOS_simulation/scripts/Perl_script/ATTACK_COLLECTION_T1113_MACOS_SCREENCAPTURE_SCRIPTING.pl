#!/bin/sh
#ATTACK_COLLECTION_T1113_MACOS_SCREENCAPTURE_SCRIPTING

system( "screencapture file2.jpg" );
