package main

import (
	"io"
	"io/ioutil"
	"os"
	"encoding/json"
	"os/exec"
	"fmt"
	"bytes"

	"github.com/creack/pty"
)

func main() {
	c := exec.Command("bash")
	// fmt.Printf("%t", c)
	f, err := pty.Start(c) // start pty
	if err != nil {
		panic(err)
	}
	// open config file
	jsonFile, err := os.Open("config.json")
        // handle error if file doesn't exist
        if err != nil {
                fmt.Println(err)
        }
        defer jsonFile.Close()
        byteValue, _ := ioutil.ReadAll(jsonFile)
        var config map[string]interface{}
        json.Unmarshal([]byte(byteValue), &config)
	passes := config["password"].(string)
	file, err := ioutil.ReadFile(os.Args[1]) // read file as a byte array
	file = bytes.Replace(file, []byte("$*"),[]byte(passes),1)
	file = append(file,[]byte{4}...) // send EOT at the end
	// fmt.Println(file)
	f.Write(file) // write the entire array
	if err != nil {
		panic(err)
	}
	io.Copy(os.Stdout, f) // copy whatever happens to stdout
	f.Close()
	os.Exit(0)
}
