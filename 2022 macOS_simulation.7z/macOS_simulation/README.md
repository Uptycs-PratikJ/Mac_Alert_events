# Introduction

This is a package containing MacOS POC testing rules for the Uptycs EDR. 

The scripts sub-directory has several scripts to execute the following:

1.Collection 
2.Commanad and Control
3.Credential Access
4.Defense Evasion
5.Discovery
6.Execution
7.Impact
8.Malicious IPs
9.Persistence
10.Privilege Escalation
11.Yara
12.Run Manually

# Prerequisite
  brew install tor 
  brew isntall wget
  brew install go
  sudo mount -uw

# Setup

In the config.json file, please replace the sample text with the password of the VM.
Build file using 'go build main.go' 

# Working

Run `./main All` to execute all the 11 steps as mentioned above.

To execute individual steps, use the following method: `./main <name of the tactic>`, for example, `./main Privilege Escalation` (this is case sensitive)

Note: Run this tool in VirtulMachine only & Simulation folder should be in a Download directory.


1. Each simulation for any particular tactic executes a series of techniques which have a 10 second delay after executing a simulation and before executing the next simulation. Ignore any error messages seen in the terminal during simulation.

2. Some scripts need to run manually that is placed inside the folder "Run Manually" with sh.<script_name>.

3. The entire simulation approximately takes 25-30 minutes.
