package main

import (
	"bufio"
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io/fs"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

var mapDir map[string][]string
var scriptDir map[int]string
var delim, ext, ending, passes string

func executeCommand(execCmd string) {
	/*
		// take command, check if it's windows or not
		// if windows, run in powershell, if not, run it in bash
		// if bash, run `tput reset` as well after each script
	*/
	if runtime.GOOS == "windows" {
		fmt.Printf("Executing %s %s", execCmd, ending)
		cmdScript := &exec.Cmd{
			Path:   "powershell",
			Args:   []string{"powershell", execCmd},
			Stdout: os.Stdout,
			Stderr: os.Stderr,
			Stdin:  os.Stdin,
		}
		if err := cmdScript.Run(); err != nil {
			// soft-fail, add to errors.csv
			fmt.Println("Error:", err)
			addcol("errors.csv", []string{execCmd, err.Error()})
		}
	} else {
		fmt.Printf("Executing %s %s", execCmd, ending)
		cmdScript := &exec.Cmd{
			Path:   "/bin/bash",
			Args:   []string{"/bin/bash", execCmd, passes},
			Stdout: os.Stdout,
			Stderr: os.Stderr,
			Stdin:  os.Stdin,
		}
		if err := cmdScript.Run(); err != nil {
			//soft-fail, add to errors.csv
			fmt.Println("FAILED:", execCmd)
			addcol("output.csv", []string{execCmd, err.Error()})
		} else {
			fmt.Println("DONE:", execCmd)
		}
		time.Sleep(10 * time.Second)
		cmdScript = &exec.Cmd{
			Path:   "/usr/bin/tput",
			Args:   []string{"/usr/bin/tput", "reset"},
			Stdout: os.Stdout,
			Stderr: os.Stderr,
			Stdin:  os.Stdin,
		}
		if err := cmdScript.Run(); err != nil {
			// hard fail if tput errors out because there are bigger problems
			log.Fatal(err)
		}

	}
}

// from https://stackoverflow.com/questions/17629451/append-slice-to-csv-golang

func addcol(fname string, column []string) {
	/*
		// Add a column into the CSV when it errors out
	*/
	// read the file
	f, err := os.OpenFile(fname, os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0644)
	if err != nil {
		fmt.Println("Error: ", err)
		return
	}
	// call Writer, write column and flush buffer
	w := csv.NewWriter(f)
	w.Write(column)
	w.Flush()
}

func printScripts(iter string) {
	/*
		// fancy formatted printing
	*/
	for i, value := range mapDir[iter] {
		fmt.Printf("%d. %s Link: https://attack.mitre.org/techniques/%s %s", i+1, value, strings.Replace(value, ".", "/", 1), ending)
	}
}

func execWhileWalk(s string, d fs.DirEntry, err error) error {
	/*
		// Used by the main function to execute all commands as it's walking the folder,
		// as opposed to crafting the filepath and executing at a time
	*/
	if strings.Count(s, delim) == 3 {
		execCmd := s
		executeCommand(execCmd)
	}
	return nil
}

func walk(s string, d fs.DirEntry, err error) error {
	/*
		// Used by filepath.WalkDir to walk through the folder including subfolders
		// Populate maps for category and subtechnique
	*/
	if err != nil {
		log.Fatal(err)
		return err
	}
	// find folders 2 subfolders deep, i.e., Category/Technique/*
	if strings.Count(s, delim) == 2 && d.IsDir() {
		// split through the delimiter
		category, technique := strings.Split(s, delim)[1], strings.Split(s, delim)[2]
		_, ok := mapDir[category]
		if ok {
			// fmt.Println(category, "exists! Appending...")
			mapDir[category] = append(mapDir[category], technique)
		} else {
			// fmt.Println(category, "does not exist! Adding...")
			mapDir[category] = []string{technique}
		}
	}
	return nil
}

func listScripts(s string, d fs.DirEntry, err error) error {
	/*
		// Used by filepath.WalkDir to walk through the folder including subfolders
		// Populate ScriptDir to print the list of subtechniques
	*/
	if err != nil {
		log.Fatal(err)
		return err
	}
	// if s is in the format Category/Technique/ScriptName
	if strings.Count(s, delim) == 3 {
		scriptName := strings.Split(s, delim)[3]
		if scriptName != "" && strings.Contains(scriptName, ext) {
			scriptDir[len(scriptDir)] = strings.Replace(scriptName, ext, "", 1)
			if scriptDir[len(scriptDir)-1] == "script" {
				fmt.Printf("%d\t\tNo rule found. %s", len(scriptDir), ending)
			} else {
				fmt.Printf("%d\t\t%s %s", len(scriptDir), scriptDir[len(scriptDir)-1], ending)
			}
		}
	}
	return nil
}

func main() {
	/*
		// Has the menu and whatever initializations are required
	*/

	// create new Reader for stdin
	reader := bufio.NewReader(os.Stdin)

	// bunch of hashmaps to help with walking through the dir
	mapDir = make(map[string][]string)
	scriptDir = make(map[int]string)
	var categoryMap, subtechniqueMap map[int]string
	categoryMap = make(map[int]string)
	subtechniqueMap = make(map[int]string)
	var category, subtechnique string

	// OS-specific changes

	if runtime.GOOS == "windows" {
		delim = "\\"
		ext = ".ps1"
		ending = "\r\n"
	} else {
		delim = "/"
		ext = ".sh"
		ending = "\n"
	}

	// Read Config file
	jsonFile, err := os.Open("config.json")

	// handle error if file doesn't exist
	if err != nil {
		log.Fatal(err)
	}
	defer jsonFile.Close()
	byteValue, _ := ioutil.ReadAll(jsonFile)
	var config map[string]interface{}
	json.Unmarshal([]byte(byteValue), &config)

	// fmt.Println(config["password"])
	var ok bool
	passes, ok = config["password"].(string)
	if !ok {
		log.Fatal("Please provide a key called 'password' in config.json")
	}

	// populate all the hashmaps
	filepath.WalkDir("scripts/", walk)

	fmt.Println("Uptycs Inc. Testing scripts")

	// check os args
	if len(os.Args) > 1 {
		// run based on what the args were
		if strings.ToLower(os.Args[1]) == "all" {
			fmt.Println("Executing all scripts in the scripts/ dir...")
			filepath.WalkDir("scripts/", execWhileWalk)
			os.Exit(0)
		} else {
			args := strings.Join(os.Args[1:], " ")
			fmt.Println("Executing from argv, Category " + args)
			err = filepath.WalkDir("scripts/"+args, execWhileWalk)
		}
		if err != nil {
			log.Fatal(err)
		} else {
			os.Exit(0)
		}
	}

	count := 1
	fmt.Println("0. Execute all scripts")
	// print amount of subtechniques

	for i, value := range mapDir {
		categoryMap[count] = i
		fmt.Println(strconv.Itoa(count)+".", i, "has", len(value), "subtechniques.")
		count++
	}
	fmt.Print("Enter the Category you want to execute. ->")

	text, _ := reader.ReadString('\n')
	text = strings.Replace(text, ending, "", 1)
	textInt, _ := strconv.Atoi(text)

	// fmt.Println(categoryMap)

	if textInt == 0 {
		// execute all
		fmt.Println("Since you have selected to run all the scripts, we will run all scripts")
		fmt.Println("These are the subtechniques that you will execute.")
		for iter := range mapDir {
			fmt.Printf("In the category %s, you will be executing:\n", iter)
			printScripts(iter)
		}
		filepath.WalkDir("scripts/", execWhileWalk)

		// immediately exit after this
		os.Exit(0)

	} else if textInt > count {
		fmt.Println("Invalid Choice. Exiting...")
	} else {
		fmt.Println("Here are the subtechniques:")
		category = categoryMap[textInt]
		// fmt.Println("category",category, textInt, text)
		count = 1
		for j, values := range mapDir[categoryMap[textInt]] {
			subtechniqueMap[count] = values
			fmt.Printf("%d. %s Link: https://attack.mitre.org/techniques/%s %s", j+1, values, strings.Replace(values, ".", "/", 1), ending)
			count++
		}
	}
	fmt.Printf("Select one -> ")
	// read input
	text, _ = reader.ReadString('\n')
	text = strings.Replace(text, ending, "", 1)
	textInt, _ = strconv.Atoi(text)
	if textInt > count {
		fmt.Println("Invalid choice.")
	} else {
		subtechnique = subtechniqueMap[textInt]
		baseDir := "scripts" + delim + category + delim + subtechnique + delim

		fmt.Printf("%s\t%s\n", "Serial No.", "Uptycs Rule")
		// list all scripts in dir
		filepath.WalkDir(baseDir, listScripts)

		fmt.Printf("Enter the Rule that you want to execute: -> ")
		text, _ := reader.ReadString('\n')
		text = strings.Replace(text, ending, "", 1)
		textInt, _ := strconv.Atoi(text)
		// execute command
		execCmd := "scripts" + delim + category + delim + subtechnique + delim + scriptDir[textInt-1] + ext
		executeCommand(execCmd)
	}
	// fmt.Println(category, subtechnique)
}
