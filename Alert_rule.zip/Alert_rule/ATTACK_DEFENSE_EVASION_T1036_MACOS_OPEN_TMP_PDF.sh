#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1036_MACOS_OPEN_TMP_PDF
sudo touch /tmp/T1036.pdf
/usr/bin/open /tmp/T1036.pdf
sudo rm -rf /tmp/T1036.pdf
