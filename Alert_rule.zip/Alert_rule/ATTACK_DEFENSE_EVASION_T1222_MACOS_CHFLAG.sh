#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1222_MACOS_CHFLAG
sudo touch T1222_002.sh
chflags hidden T1222_002.sh
