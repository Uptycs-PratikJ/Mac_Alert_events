#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1222_MACOS_SUDO_CHOWN
sudo touch T1222.sh
sudo -p chown T1222.sh
sudo rm T1222.sh
