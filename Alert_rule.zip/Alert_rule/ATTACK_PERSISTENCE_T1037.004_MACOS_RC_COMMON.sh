#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1037.004_MACOS_RC_COMMON
echo "Validating T1037.004" | sudo tee /etc/rc.common
