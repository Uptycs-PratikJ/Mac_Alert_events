#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1553_MACOS_SUDO_XATTR
sudo xattr -lr * / 2>&1 /dev/null | grep -C 2 "00 00 00 00 00 00 00 00 40 00 FF FF FF FF 00 00"
