#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1562_MACOS_KILALL_TERMINAL
killall Terminal.app
