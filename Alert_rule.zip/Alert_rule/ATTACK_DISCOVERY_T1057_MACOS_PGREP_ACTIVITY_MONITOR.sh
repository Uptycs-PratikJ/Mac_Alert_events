#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1057_MACOS_PGREP_ACTIVITY_MONITOR
/usr/bin/pgrep Activity Monitor
