#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_FILE_LAUNCHD_CONF
touch /etc/launchd.conf
rm -rf /etc/launchd.conf
