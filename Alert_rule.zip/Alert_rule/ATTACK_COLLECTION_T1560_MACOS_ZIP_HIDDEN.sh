#!/usr/bin/env sh
# ATTACK_COLLECTION_T1560_MACOS_ZIP_HIDDEN
zip /tmp/.
