#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1562_MACOS_PKILL
pkill cfprefsd
