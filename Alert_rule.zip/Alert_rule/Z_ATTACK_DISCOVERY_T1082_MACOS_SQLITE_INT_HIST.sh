#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1082_MACOS_SQLITE_INT_HIST
sqlite3 LSQuarantineEvent
