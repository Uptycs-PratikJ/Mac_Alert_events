#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1553_MACOS_SPCTL
sudo spctl master-disable
