#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1037_MACOS_BOOT_OR_LOGON_FILE
sudo echo "hacker3" >> /Library/StartupItems/file2
sudo echo "hacker34" >> /Library/StartupItems/file2
sudo rm -rf /Library/StartupItems/file2