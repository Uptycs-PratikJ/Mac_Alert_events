#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1159_MACOS_EXTENSIONS_MOD
sudo touch /Library/Extensions/T1159.kext
sudo rm /Library/Extensions/T1159.kext
