#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1027_MACOS_OPENSSL_INKEY_ENCRYPT
openssl rsautl -encrypt -inkey public_key.pem -pubin -in encrypt.txt -out encrypt.dat
