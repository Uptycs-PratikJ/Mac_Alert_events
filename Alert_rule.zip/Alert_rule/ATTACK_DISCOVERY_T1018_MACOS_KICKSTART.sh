#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1018_MACOS_KICKSTART
perl -configure kickstart ARDAgent.app
