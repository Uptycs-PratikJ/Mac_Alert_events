#!/usr/bin/env sh
# ATTACK_PRIVILEGE_ESCALATION_T1548_MACOS_ETC_PASSWD_FILE
echo " " >> /etc/passwd
