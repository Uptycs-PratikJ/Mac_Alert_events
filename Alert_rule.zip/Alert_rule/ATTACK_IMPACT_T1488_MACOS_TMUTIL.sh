#!/usr/bin/env sh
# ATTACK_IMPACT_T1488_MACOS_TMUTIL
tmutil delete
