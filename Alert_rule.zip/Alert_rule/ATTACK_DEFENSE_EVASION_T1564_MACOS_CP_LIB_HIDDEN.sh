#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1564_MACOS_CP_LIB_HIDDEN
touch ~/Library/.T1564
cp ~/Library/.T1564 ~/Downloads
rm -rf ~/Downloads/.T1564

