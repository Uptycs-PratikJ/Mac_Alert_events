#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1543_MACOS_TOUCH_LAUNCHDAEMONS
sudo touch /Library/LaunchDaemons/T1543.plist
sudo rm /Library/LaunchDaemons/T1543.plist
