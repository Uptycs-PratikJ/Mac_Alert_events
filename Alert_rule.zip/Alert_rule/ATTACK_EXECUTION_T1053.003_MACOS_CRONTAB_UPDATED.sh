#!/usr/bin/env sh
# ATTACK_EXECUTION_T1053.003_MACOS_CRONTAB_UPDATED
echo '* * * * * echo "crontab gets updated"' | crontab -
