#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1135_MACOS_NETWORK_SHARE_DISCOVERY_SMBUTIL
smbutil view -g /private/var/vm
