#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1159_MACOS_FILE_PLIST_HIDDEN
cp /Library/LaunchAgents/com.vmware.launchd.vmware-tools-userd.plist ~/Downloads/.com.vmware.launchd.vmware-tools-userd.plist
rm -rf ~/Downloads/.com.vmware.launchd.vmware-tools-userd.plist