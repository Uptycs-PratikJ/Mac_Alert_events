#!/usr/bin/env sh

#ATTACK_PERSISTENCE_T1159_MACOS_PROFILE_CONF_FILE_MOD.sh

echo " " >> /etc/defaults/periodic.conf