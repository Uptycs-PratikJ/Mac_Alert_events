#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1159_MACOS_EMOND_CONF_FILE_MOD
echo "T1159" >> /etc/emond.d/rules/T1159.plist
rm -rf /etc/emond.d/rules/T1159.plist
