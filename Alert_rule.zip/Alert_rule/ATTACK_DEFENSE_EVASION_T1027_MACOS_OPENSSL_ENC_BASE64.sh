#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1027_MACOS_OPENSSL_ENC_BASE64
sudo touch ~/Downloads/T1027.txt
openssl enc -base64 -in ~/Downloads/T1027.txt -out ~/Downloads/base64_encrypted
sudo rm -rf ~/Downloads/T1027.txt
sudo rm -rf ~/Downloads/base64_encrypted
