#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1564_MACOS_TOUCH_HIDDEN_LIB
touch ~/Library/.T1564
rm -rf ~/Library/.T1564
