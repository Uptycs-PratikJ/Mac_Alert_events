#!/usr/bin/env sh
#ATTACK_PERSISTENCE_T1159_MACOS_CRON_FILE_MOD
echo "uptycs" >> /usr/lib/cron/tmp/file1
rm -rf /usr/lib/tmp/file1
