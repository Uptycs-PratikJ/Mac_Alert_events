#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1222_MACOS_SUDO_CHMOD
sudo touch T1222.sh
sudo -p chmod T1222.sh
sudo rm -rf T1222.sh
