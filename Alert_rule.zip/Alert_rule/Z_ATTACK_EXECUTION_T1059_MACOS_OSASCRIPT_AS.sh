#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_OSASCRIPT_AS
osascript -l applescript
