#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1057_MACOS_GREP_ACTIVITY_CREDENTIALS
sudo /usr/bin/grep -rni 'Cookies.binarycookies' /
