#!/usr/bin/env sh
# ATTACK_DEFENSE_EVASION_T1564_MACOS_HIDDEN_FILE_SUPPORT_DIR
cp /bin/pwd /Library/Application\ Support/.pwdcopy
/Library/Application\ Support/.pwdcopy
rm -rf /Library/Application\ Support/.pwdcopy

