#!/usr/bin/env sh
# ATTACK_EXECUTION_T1059_MACOS_PYTHON_SCRIPT
python subprocess.call
