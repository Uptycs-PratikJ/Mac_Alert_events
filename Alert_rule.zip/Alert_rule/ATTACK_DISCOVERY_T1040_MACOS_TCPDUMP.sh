#!/usr/bin/env sh
# ATTACK_DISCOVERY_T1040_MACOS_TCPDUMP
sudo tcpdump -c 4 -I en0
