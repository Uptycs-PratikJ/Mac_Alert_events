#!/usr/bin/env sh
# ATTACK_IMPACT_T1561_MACOS_DD_OF
dd of=/dev/disk
